<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'lawttery');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '$nt}m).Sg#MM,2@#Za4?)N4F/o[?WzTHf1+X[Lho6?W+:3dx<UXl!lATi>A,:a<9');
define('SECURE_AUTH_KEY',  '&110;WLrqViFU?py:QAWSP2wy>]#mF>W0%dL3osLYW</V`!,Xd{09-t1]}KWO1Nh');
define('LOGGED_IN_KEY',    'q!_n%q5cycHmxQgoMc^=Vm#@e++[P,UG-sZkjfHD}l,:0#1llscdOY@)?vJ~EE3%');
define('NONCE_KEY',        'Q,s(6Q7@M}FocKn+BNwf+^jg!-6/*-s?cRXf!Fy2.ca?K~5#GEx-])>UR4rx_qHm');
define('AUTH_SALT',        'wx Xqe:HDt (,l 45j?@&7F`OO},~6)DJIVSP+L&K+q| <oEQ(?zHF`Y#n9LD%o5');
define('SECURE_AUTH_SALT', 'oSp_LL;!B9mX;vudOzp5CFQ)=<C*%f#oGO!yWue%y.|Ib-9jVTbT^2(OvLC%o_Y|');
define('LOGGED_IN_SALT',   'sAy(u&.3$Oju.M}d`9t@}1=PFO_O.~|Y(eyZVbt-cKtjE<~6I*l4vZIDz8WVBb9O');
define('NONCE_SALT',       '!%& )&ehA~J8v6,&H+([m!`xF |A<|dA`:$aA$$GhD?Y2eCK4^7_{4*z;MeXk@(6');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'lw_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
